<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	
	$orderId = $_POST['orderId'];

	$orderDate 						= date('Y-m-d', strtotime($_POST['orderDate']));
  $clientName 					= $_POST['clientName'];
  $clientContact 				= $_POST['clientContact'];
  $subTotalValue 				= $_POST['subTotalValue'];
  $vatValue 						=	$_POST['vatValue'];
  $totalAmountValue     = $_POST['totalAmountValue'];
  $discount 						= $_POST['discount'];
  $grandTotalValue 			= $_POST['grandTotalValue'];
  $paid 								= $_POST['paid'];
  $dueValue 						= $_POST['dueValue'];
  $paymentType 					= $_POST['paymentType'];
  $paymentStatus 				= $_POST['paymentStatus'];

				
	$sql = "UPDATE orders SET order_date = '$orderDate', client_name = '$clientName', client_contact = '$clientContact', sub_total = '$subTotalValue', vat = '$vatValue', total_amount = '$totalAmountValue', discount = '$discount', grand_total = '$grandTotalValue', paid = '$paid', due = '$dueValue', payment_type = '$paymentType', payment_status = '$paymentStatus', order_status = 1 WHERE order_id = {$orderId}";	
	$connect->query($sql);
	
	$readyToUpdateOrderItem = false;
	for($x = 0; $x < count($_POST['parameterName']); $x++) {		
		$updateparameterQuantitySql = "SELECT parameter.quantity FROM parameter WHERE parameter.parameter_id = ".$_POST['parameterName'][$x]."";
		$updateparameterQuantityData = $connect->query($updateparameterQuantitySql);			
			
		while ($updateparameterQuantityResult = $updateparameterQuantityData->fetch_row()) {
			$orderItemTableSql = "SELECT order_item.quantity FROM order_item WHERE order_item.order_id = {$orderId}";
			$orderItemResult = $connect->query($orderItemTableSql);
			$orderItemData = $orderItemResult->fetch_row();

			$editQuantity = $updateparameterQuantityResult[0] + $orderItemData[0];							

			$updateQuantitySql = "UPDATE parameter SET quantity = $editQuantity WHERE parameter_id = ".$_POST['parameterName'][$x]."";
			$connect->query($updateQuantitySql);		
		} 
		
		if(count($_POST['parameterName']) == count($_POST['parameterName'])) {
			$readyToUpdateOrderItem = true;			
		}
	} 

	for($x = 0; $x < count($_POST['parameterName']); $x++) {			
		$removeOrderSql = "DELETE FROM order_item WHERE order_id = {$orderId}";
		$connect->query($removeOrderSql);	
	} 

	if($readyToUpdateOrderItem) {
		for($x = 0; $x < count($_POST['parameterName']); $x++) {			
			$updateparameterQuantitySql = "SELECT parameter.quantity FROM parameter WHERE parameter.parameter_id = ".$_POST['parameterName'][$x]."";
			$updateparameterQuantityData = $connect->query($updateparameterQuantitySql);
			
			while ($updateparameterQuantityResult = $updateparameterQuantityData->fetch_row()) {
				$updateQuantity[$x] = $updateparameterQuantityResult[0] - $_POST['quantity'][$x];							
					$updateparameterTable = "UPDATE parameter SET quantity = '".$updateQuantity[$x]."' WHERE parameter_id = ".$_POST['parameterName'][$x]."";
					$connect->query($updateparameterTable);

				$orderItemSql = "INSERT INTO order_item (order_id, parameter_id, quantity, rate, total, order_item_status) 
				VALUES ({$orderId}, '".$_POST['parameterName'][$x]."', '".$_POST['quantity'][$x]."', '".$_POST['rateValue'][$x]."', '".$_POST['totalValue'][$x]."', 1)";

				$connect->query($orderItemSql);		
			} 	
		} 
	}

	

	$valid['success'] = true;
	$valid['messages'] = "Successfully Updated";		
	
	$connect->close();

	echo json_encode($valid);
 
} 
