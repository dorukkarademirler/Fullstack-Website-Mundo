<?php 	

require_once 'core.php';

$parameterId = $_GET['i'];

$sql = "SELECT parameter_image FROM parameter WHERE parameter_id = {$parameterId}";
$data = $connect->query($sql);
$result = $data->fetch_row();

$connect->close();

echo "stock/" . $result[0];
