<?php 	

require_once 'core.php';

$sql = "SELECT product_id, product_name, product_active, product_status FROM product WHERE product_status = 1";
$result = $connect->query($sql);

$output = array('data' => array());

if($result->num_rows > 0) { 

 $activeproduct = ""; 

 while($row = $result->fetch_array()) {
 	$productId = $row[0];
 	
 	if($row[2] == 1) {
 	
 		$activeproduct = "<label class='label label-success'>Available in Stock</label>";
 	} else {
 		
 		$activeproduct = "<label class='label label-danger'>Not Available</label>";
 	}

 	$button = '<!-- Single button -->
	<div class="btn-group">
	<a type="button" data-toggle="modal" id="addproductModalBtn" data-target="#addproductModal" onclick="addproduct('.$productId.')">Add</a>
	 	   <a type="button" data-toggle="modal" id="editproductModalBtn" data-target="#editproductModal" onclick="editproduct('.$productId.')">Edit</a>
	    <a type="button" data-toggle="modal" data-target="#removeproductModal" id="removeproductModalBtn" onclick="removeproduct('.$productId.')">Remove</a>       
	  
	</div>';

 	$output['data'][] = array( 		
 		$row[1], 		
 		$activeproduct,
 		$button 		
 		); 	
 }

}

$connect->close();

echo json_encode($output);