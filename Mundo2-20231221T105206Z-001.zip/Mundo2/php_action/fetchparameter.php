<?php 	



require_once 'core.php';

$sql = "SELECT parameter.parameter_id, parameter.parameter_name, parameter.parameter_image, parameter.company_id,
 		parameter.product_id, parameter.quantity, parameter.rate, parameter.active, parameter.status, 
 		company.company_name, product.product_name FROM parameter 
		INNER JOIN company ON parameter.company_id = company.company_id 
		INNER JOIN product ON parameter.product_id = product.product_id  
		WHERE parameter.status = 1";

$result = $connect->query($sql);

$output = array('data' => array());

if($result->num_rows > 0) { 

 $active = ""; 

 while($row = $result->fetch_array()) {
 	$parameterId = $row[0];
 	if($row[7] == 1) {
 		$active = "<label class='label label-success'>Available in Stock</label>";
 	} else {
 		$active = "<label class='label label-danger'>Not Available</label>";
 	} 

 	$button = '<!-- Single button -->
	<div class="btn-group">
	  <a type="button" data-toggle="modal" id="addparameterModalBtn" data-target="#addparameterModal" onclick="addparameter('.$parameterId.')"> Add        </a>
	    <a type="button" data-toggle="modal" id="editparameterModalBtn" data-target="#editparameterModal" onclick="editparameter('.$parameterId.')"> Edit        </a>
	   <a type="button" data-toggle="modal" data-target="#removeparameterModal" id="removeparameterModalBtn" onclick="removeparameter('.$parameterId.')">  Remove</a>      
	  
	</div>';

	

	$company = $row[9];
	$product = $row[10];

	$imageUrl = substr($row[2], 3);
	$parameterImage = "<img class='img-round' src='".$imageUrl."' style='height:30px; width:50px;'  />";

 	$output['data'][] = array( 		
 		$parameterImage,
 		$row[1], 
 		$row[6],
 		$row[5], 		 	
 		$company,
 		$product,
 		$active,
 		$button 		
 		); 	
 } 

}

$connect->close();

echo json_encode($output);