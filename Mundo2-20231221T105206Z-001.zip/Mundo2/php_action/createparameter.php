<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	

	$parameterName 		= $_POST['parameterName'];
  // $parameterImage 	= $_POST['parameterImage'];
  $quantity 			= $_POST['quantity'];
  $rate 					= $_POST['rate'];
  $companyName 			= $_POST['companyName'];
  $productName 	= $_POST['productName'];
  $parameterStatus 	= $_POST['parameterStatus'];

	$type = explode('.', $_FILES['parameterImage']['name']);
	$type = $type[count($type)-1];		
	$url = '../assests/images/stock/'.uniqid(rand()).'.'.$type;
	if(in_array($type, array('gif', 'jpg', 'jpeg', 'png', 'JPG', 'GIF', 'JPEG', 'PNG'))) {
		if(is_uploaded_file($_FILES['parameterImage']['tmp_name'])) {			
			if(move_uploaded_file($_FILES['parameterImage']['tmp_name'], $url)) {
				
				$sql = "INSERT INTO parameter (parameter_name, parameter_image, company_id, product_id, quantity, rate, active, status) 
				VALUES ('$parameterName', '$url', '$companyName', '$productName', '$quantity', '$rate', '$parameterStatus', 1)";

				if($connect->query($sql) === TRUE) {
					$valid['success'] = true;
					$valid['messages'] = "Successfully Added";	
				} else {
					$valid['success'] = false;
					$valid['messages'] = "Error while adding the parameter";
				}

			}	else {
				return false;
			}		
		} 
	} 		

	$connect->close();

	echo json_encode($valid);
 
} 