<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {
	$parameterId = $_POST['parameterId'];
	$parameterName 		= $_POST['editparameterName']; 
  $quantity 			= $_POST['editQuantity'];
  $rate 					= $_POST['editRate'];
  $companyName 			= $_POST['editcompanyName'];
  $productName 	= $_POST['editproductName'];
  $parameterStatus 	= $_POST['editparameterStatus'];

				
	$sql = "UPDATE parameter SET parameter_name = '$parameterName', company_id = '$companyName', product_id = '$productName', quantity = '$quantity', rate = '$rate', active = '$parameterStatus', status = 1 WHERE parameter_id = $parameterId ";

	if($connect->query($sql) === TRUE) {
		$valid['success'] = true;
		$valid['messages'] = "Successfully Update";	
	} else {
		$valid['success'] = false;
		$valid['messages'] = "Error while updating parameter";
	}

}
	 
$connect->close();

echo json_encode($valid);
 
