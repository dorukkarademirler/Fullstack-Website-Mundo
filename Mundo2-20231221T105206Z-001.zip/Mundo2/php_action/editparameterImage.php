<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {		

$parameterId = $_POST['parameterId'];
 
$type = explode('.', $_FILES['editparameterImage']['name']);
	$type = $type[count($type)-1];		
	$url = '../assests/images/stock/'.uniqid(rand()).'.'.$type;
	if(in_array($type, array('gif', 'jpg', 'jpeg', 'png', 'JPG', 'GIF', 'JPEG', 'PNG'))) {
		if(is_uploaded_file($_FILES['editparameterImage']['tmp_name'])) {			
			if(move_uploaded_file($_FILES['editparameterImage']['tmp_name'], $url)) {

				$sql = "UPDATE parameter SET parameter_image = '$url' WHERE parameter_id = $parameterId";				

				if($connect->query($sql) === TRUE) {									
					$valid['success'] = true;
					$valid['messages'] = "Successfully Updated";	
				} else {
					$valid['success'] = false;
					$valid['messages'] = "Error while updating parameter image";
				}
			}	else {
				return false;
			}		
		} 
	} 		
	 
	$connect->close();

	echo json_encode($valid);
 
} 