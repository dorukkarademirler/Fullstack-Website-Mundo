<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	

	$companyName = $_POST['editproductName'];
  $companyStatus = $_POST['editproductStatus']; 
  $productId = $_POST['editproductId'];

	$sql = "UPDATE product SET product_name = '$companyName', product_active = '$companyStatus' WHERE product_id = '$productId'";

	if($connect->query($sql) === TRUE) {
	 	$valid['success'] = true;
		$valid['messages'] = "Successfully Updated";	
	} else {
	 	$valid['success'] = false;
	 	$valid['messages'] = "Error while updating the product";
	}
	 
	$connect->close();

	echo json_encode($valid);
 
} 