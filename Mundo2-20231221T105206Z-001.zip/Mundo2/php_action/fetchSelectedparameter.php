<?php 	

require_once 'core.php';

$parameterId = $_POST['parameterId'];

$sql = "SELECT parameter_id, parameter_name, parameter_image, company_id, product_id, quantity, rate, active, status FROM parameter WHERE parameter_id = $parameterId";
$result = $connect->query($sql);

if($result->num_rows > 0) { 
 $row = $result->fetch_array();
} 

$connect->close();

echo json_encode($row);