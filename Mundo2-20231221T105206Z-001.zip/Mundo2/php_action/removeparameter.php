<?php 	

require_once 'core.php';


$valid['success'] = array('success' => false, 'messages' => array());

$parameterId = $_POST['parameterId'];

if($parameterId) { 

 $sql = "UPDATE parameter SET active = 2, status = 2 WHERE parameter_id = {$parameterId}";

 if($connect->query($sql) === TRUE) {
 	$valid['success'] = true;
	$valid['messages'] = "Successfully Removed";		
 } else {
 	$valid['success'] = false;
 	$valid['messages'] = "Error while removing the parameter";
 }
 
 $connect->close();

 echo json_encode($valid);
 
}