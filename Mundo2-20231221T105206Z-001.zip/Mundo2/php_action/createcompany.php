<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	

	$companyName = $_POST['companyName'];
  $companyStatus = $_POST['companyStatus']; 

	$sql = "INSERT INTO company (company_name, company_active, company_status) VALUES ('$companyName', '$companyStatus', 1)";

	if($connect->query($sql) === TRUE) {
	 	$valid['success'] = true;
		$valid['messages'] = "Successfully Added";	
	} else {
	 	$valid['success'] = false;
	 	$valid['messages'] = "Error while adding the company";
	}
	 

	$connect->close();

	echo json_encode($valid);
 
} 