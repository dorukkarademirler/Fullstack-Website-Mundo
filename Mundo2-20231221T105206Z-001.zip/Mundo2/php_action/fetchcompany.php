<?php 	

require_once 'core.php';

$sql = "SELECT company_id, company_name, company_active, company_status FROM company WHERE company_status = 1";
$result = $connect->query($sql);

$output = array('data' => array());

if($result->num_rows > 0) { 


 $activecompany = ""; 

 while($row = $result->fetch_array()) {
 	$companyId = $row[0];
 	if($row[2] == 1) {
 		$activecompany = "<label class='label label-success'>Available in Stock</label>";
 	} else {
 		$activecompany = "<label class='label label-danger'>Not Available</label>";
 	}

 	$button = '<!-- Single button -->
	<div class="btn-group">
	 
	  <a type="button" data-toggle="modal" data-target="#addcompanyModel" onclick="addcompany('.$companyId.')"> Add</a>
	   <a type="button" data-toggle="modal" data-target="#editcompanyModel" onclick="editcompany('.$companyId.')"> Edit</a>
	   <a type="button" data-toggle="modal" data-target="#removeMemberModal" onclick="removecompany('.$companyId.')"> Remove</a>	 
				      
	 
	  
	</div>';

 	$output['data'][] = array( 		
 		$row[1], 		
 		$activecompany,
 		$button
		
 		); 	
 } 

} 

$connect->close();

echo json_encode($output);