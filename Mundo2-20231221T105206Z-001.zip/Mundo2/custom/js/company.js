var managecompanyTable;

$(document).ready(function() {
	$('#navcompany').addClass('active');
		managecompanyTable = $("#managecompanyTable").DataTable({
		'ajax': 'php_action/fetchcompany.php',
		'order': []		
	});

	$("#submitcompanyForm").unbind('submit').bind('submit', function() {
		$(".text-danger").remove();
		$('.form-group').removeClass('has-error').removeClass('has-success');			
		var companyName = $("#companyName").val();
		var companyStatus = $("#companyStatus").val();
		if(companyName == "") {
			$("#companyName").after('<p class="text-danger">company Name is required</p>');
			$('#companyName').closest('.form-group').addClass('has-error');
		} else {
			$("#companyName").find('.text-danger').remove();
			$("#companyName").closest('.form-group').addClass('has-success');	  	
		}

		if(companyStatus == "") {
			$("#companyStatus").after('<p class="text-danger">company Name is required</p>');
			$('#companyStatus').closest('.form-group').addClass('has-error');
		} else {
			$("#companyStatus").find('.text-danger').remove();
			$("#companyStatus").closest('.form-group').addClass('has-success');	  	
		}

		if(companyName && companyStatus) {
			var form = $(this);
			$("#createcompanyBtn").button('loading');
			$.ajax({
				url : form.attr('action'),
				type: form.attr('method'),
				data: form.serialize(),
				dataType: 'json',
				success:function(response) {
					$("#createcompanyBtn").button('reset');
					if(response.success == true) {
						managecompanyTable.ajax.reload(null, false);						
						$("#submitcompanyForm")[0].reset();
						$(".text-danger").remove();
						$('.form-group').removeClass('has-error').removeClass('has-success');
  	  			$('#add-company-messages').html('<div class="alert alert-success">'+
            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
            '<strong>Ok</strong> '+ response.messages +
          '</div>');

  	  			$(".alert-success").delay(500).show(10, function() {
							$(this).delay(3000).hide(10, function() {
								$(this).remove();
							});
						}); 
					}  

				} 
			}); 	
		} 

		return false;
	}); 

});

function editcompany(companyId = null) {
	if(companyId) {
		$('#companyId').remove();
		$('.text-danger').remove();
		$('.form-group').removeClass('has-error').removeClass('has-success');
		$('.modal-loading').removeClass('div-hide');
		$('.edit-company-result').addClass('div-hide');
		$('.editcompanyFooter').addClass('div-hide');
		$.ajax({
			url: 'php_action/fetchSelectedcompany.php',
			type: 'post',
			data: {companyId : companyId},
			dataType: 'json',
			success:function(response) {
				$('.modal-loading').addClass('div-hide');
				$('.edit-company-result').removeClass('div-hide');
				$('.editcompanyFooter').removeClass('div-hide');
				$('#editcompanyName').val(response.company_name);
				$('#editcompanyStatus').val(response.company_active);
				$(".editcompanyFooter").after('<input type="hidden" name="companyId" id="companyId" value="'+response.company_id+'" />');
				$('#editcompanyForm').unbind('submit').bind('submit', function() {
					$(".text-danger").remove();
					$('.form-group').removeClass('has-error').removeClass('has-success');			
					var companyName = $('#editcompanyName').val();
					var companyStatus = $('#editcompanyStatus').val();
					if(companyName == "") {
						$("#editcompanyName").after('<p class="text-danger">company Name field is required</p>');
						$('#editcompanyName').closest('.form-group').addClass('has-error');
					} else {
						$("#editcompanyName").find('.text-danger').remove();
						$("#editcompanyName").closest('.form-group').addClass('has-success');	  	
					}

					if(companyStatus == "") {
						$("#editcompanyStatus").after('<p class="text-danger">company Name field is required</p>');

						$('#editcompanyStatus').closest('.form-group').addClass('has-error');
					} else {
						$("#editcompanyStatus").find('.text-danger').remove();
						$("#editcompanyStatus").closest('.form-group').addClass('has-success');	  	
					}

					if(companyName && companyStatus) {
						var form = $(this);
						$('#editcompanyBtn').button('loading');

						$.ajax({
							url: form.attr('action'),
							type: form.attr('method'),
							data: form.serialize(),
							dataType: 'json',
							success:function(response) {

								if(response.success == true) {
									console.log(response);
									$('#editcompanyBtn').button('reset');
									managecompanyTable.ajax.reload(null, false);								  	  										
									$(".text-danger").remove();
									$('.form-group').removeClass('has-error').removeClass('has-success');
			  	  			
			  	  			$('#edit-company-messages').html('<div class="alert alert-success">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong>Ok</i></strong> '+ response.messages +
			          '</div>');

			  	  			$(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									}); 
								} 
									
							}
						});	 											
					} 

					return false;
				}); 

			} 
		}); 

	} else {
		alert('error!! Refresh the page again');
	}
} 

function removecompany(companyId = null) {
	if(companyId) {
		$('#removecompanyId').remove();
		$.ajax({
			url: 'php_action/fetchSelectedcompany.php',
			type: 'post',
			data: {companyId : companyId},
			dataType: 'json',
			success:function(response) {
				$('.removecompanyFooter').after('<input type="hidden" name="removecompanyId" id="removecompanyId" value="'+response.company_id+'" /> ');

				$("#removecompanyBtn").unbind('click').bind('click', function() {
					$("#removecompanyBtn").button('loading');

					$.ajax({
						url: 'php_action/removecompany.php',
						type: 'post',
						data: {companyId : companyId},
						dataType: 'json',
						success:function(response) {
							console.log(response);
							$("#removecompanyBtn").button('reset');
							if(response.success == true) {

								$('#removeMemberModal').modal('hide');

								managecompanyTable.ajax.reload(null, false);
								
								$('.remove-messages').html('<div class="alert alert-success">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong>Ok</strong> '+ response.messages +
			          '</div>');

			  	  			$(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									}); 
							} else {

							} 
						} 
					}); 

				}); 

			} 
		}); 

		$('.removecompanyFooter').after();
	} else {
		alert('error!! Refresh the page again');
	}
} 