var manageparameterTable;

$(document).ready(function() {
	$('#navparameter').addClass('active');
	manageparameterTable = $('#manageparameterTable').DataTable({
		'ajax': 'php_action/fetchparameter.php',
		'order': []
	});

	$("#addparameterModalBtn").unbind('click').bind('click', function() {
		$("#submitparameterForm")[0].reset();		

		$(".text-danger").remove();
		$(".form-group").removeClass('has-error').removeClass('has-success');

		$("#parameterImage").fileinput({
	      overwriteInitial: true,
		    maxFileSize: 2500,
		    showClose: false,
		    showCaption: false,
		    browseLabel: '',
		    removeLabel: '',
		    browseIcon: '<i class="glyphicon glyphicon-folder-open"></i>',
		    removeIcon: '<i class="glyphicon glyphicon-remove"></i>',
		    removeTitle: 'Cancel or reset changes',
		    elErrorContainer: '#kv-avatar-errors-1',
		    msgErrorClass: 'alert alert-block alert-danger',
		    defaultPreviewContent: '<img src="assests/images/default.png" alt="Profile Image" style="width:100%;">',
		    layoutTemplates: {main2: '{preview} {remove} {browse}'},								    
	  		allowedFileExtensions: ["jpg", "png", "gif", "JPG", "PNG", "GIF"]
			});   

		$("#submitparameterForm").unbind('submit').bind('submit', function() {

			var parameterImage = $("#parameterImage").val();
			var parameterName = $("#parameterName").val();
			var quantity = $("#quantity").val();
			var rate = $("#rate").val();
			var companyName = $("#companyName").val();
			var productName = $("#productName").val();
			var parameterStatus = $("#parameterStatus").val();
	
			if(parameterImage == "") {
				$("#parameterImage").closest('.center-block').after('<p class="text-danger">parameter Image field is required</p>');
				$('#parameterImage').closest('.form-group').addClass('has-error');
			}	else {
				$("#parameterImage").find('.text-danger').remove();
				$("#parameterImage").closest('.form-group').addClass('has-success');	  	
			}	

			if(parameterName == "") {
				$("#parameterName").after('<p class="text-danger">parameter Name field is required</p>');
				$('#parameterName').closest('.form-group').addClass('has-error');
			}	else {
				$("#parameterName").find('.text-danger').remove();
				$("#parameterName").closest('.form-group').addClass('has-success');	  	
			}	

			if(quantity == "") {
				$("#quantity").after('<p class="text-danger">Quantity field is required</p>');
				$('#quantity').closest('.form-group').addClass('has-error');
			}	else {
				$("#quantity").find('.text-danger').remove();
				$("#quantity").closest('.form-group').addClass('has-success');	  	
			}	

			if(rate == "") {
				$("#rate").after('<p class="text-danger">Rate field is required</p>');
				$('#rate').closest('.form-group').addClass('has-error');
			}	else {
				$("#rate").find('.text-danger').remove();
				$("#rate").closest('.form-group').addClass('has-success');	  	
			}	

			if(companyName == "") {
				$("#companyName").after('<p class="text-danger">company Name field is required</p>');
				$('#companyName').closest('.form-group').addClass('has-error');
			}	else {
				$("#companyName").find('.text-danger').remove();
				$("#companyName").closest('.form-group').addClass('has-success');	  	
			}	

			if(productName == "") {
				$("#productName").after('<p class="text-danger">product Name field is required</p>');
				$('#productName').closest('.form-group').addClass('has-error');
			}	else {
				$("#productName").find('.text-danger').remove();
				$("#productName").closest('.form-group').addClass('has-success');	  	
			}	

			if(parameterStatus == "") {
				$("#parameterStatus").after('<p class="text-danger">parameter Status field is required</p>');
				$('#parameterStatus').closest('.form-group').addClass('has-error');
			}	else {
				$("#parameterStatus").find('.text-danger').remove();
				$("#parameterStatus").closest('.form-group').addClass('has-success');	  	
			}	

			if(parameterImage && parameterName && quantity && rate && companyName && productName && parameterStatus) {
				$("#createparameterBtn").button('loading');

				var form = $(this);
				var formData = new FormData(this);

				$.ajax({
					url : form.attr('action'),
					type: form.attr('method'),
					data: formData,
					dataType: 'json',
					cache: false,
					contentType: false,
					processData: false,
					success:function(response) {

						if(response.success == true) {
							$("#createparameterBtn").button('reset');
							
							$("#submitparameterForm")[0].reset();

							$("html, body, div.modal, div.modal-content, div.modal-body").animate({scrollTop: '0'}, 100);
																	
							$('#add-parameter-messages').html('<div class="alert alert-success">'+
		            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
		            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
		          '</div>');

		          $(".alert-success").delay(500).show(10, function() {
								$(this).delay(3000).hide(10, function() {
									$(this).remove();
								});
							});

							manageparameterTable.ajax.reload(null, true);

							$(".text-danger").remove();
							$(".form-group").removeClass('has-error').removeClass('has-success');

						} 
						
					} 
				}); 
			}	 					

			return false;
		}); 

	}); 
	


}); 

function editparameter(parameterId = null) {

	if(parameterId) {
		$("#parameterId").remove();		
		$(".text-danger").remove();
		$(".form-group").removeClass('has-error').removeClass('has-success');
		$('.div-loading').removeClass('div-hide');
		$('.div-result').addClass('div-hide');

		$.ajax({
			url: 'php_action/fetchSelectedparameter.php',
			type: 'post',
			data: {parameterId: parameterId},
			dataType: 'json',
			success:function(response) {		
				$('.div-loading').addClass('div-hide');
				$('.div-result').removeClass('div-hide');				

				$("#getparameterImage").attr('src', 'stock/'+response.parameter_image);

				$("#editparameterImage").fileinput({		      
				});  

				
				$(".editparameterFooter").append('<input type="hidden" name="parameterId" id="parameterId" value="'+response.parameter_id+'" />');				
				$(".editparameterPhotoFooter").append('<input type="hidden" name="parameterId" id="parameterId" value="'+response.parameter_id+'" />');				
				
				$("#editparameterName").val(response.parameter_name);
				$("#editQuantity").val(response.quantity);
				$("#editRate").val(response.rate);
				$("#editcompanyName").val(response.company_id);
				$("#editproductName").val(response.product_id);
				$("#editparameterStatus").val(response.active);

				$("#editparameterForm").unbind('submit').bind('submit', function() {

					var parameterImage = $("#editparameterImage").val();
					var parameterName = $("#editparameterName").val();
					var quantity = $("#editQuantity").val();
					var rate = $("#editRate").val();
					var companyName = $("#editcompanyName").val();
					var productName = $("#editproductName").val();
					var parameterStatus = $("#editparameterStatus").val();
								

					if(parameterName == "") {
						$("#editparameterName").after('<p class="text-danger">parameter Name field is required</p>');
						$('#editparameterName').closest('.form-group').addClass('has-error');
					}	else {
						$("#editparameterName").find('.text-danger').remove();
						$("#editparameterName").closest('.form-group').addClass('has-success');	  	
					}

					if(quantity == "") {
						$("#editQuantity").after('<p class="text-danger">Quantity field is required</p>');
						$('#editQuantity').closest('.form-group').addClass('has-error');
					}	else {
						$("#editQuantity").find('.text-danger').remove();
						$("#editQuantity").closest('.form-group').addClass('has-success');	  	
					}

					if(rate == "") {
						$("#editRate").after('<p class="text-danger">Rate field is required</p>');
						$('#editRate').closest('.form-group').addClass('has-error');
					}	else {
						$("#editRate").find('.text-danger').remove();
						$("#editRate").closest('.form-group').addClass('has-success');	  	
					}	

					if(companyName == "") {
						$("#editcompanyName").after('<p class="text-danger">company Name field is required</p>');
						$('#editcompanyName').closest('.form-group').addClass('has-error');
					}	else {
						$("#editcompanyName").find('.text-danger').remove();
						$("#editcompanyName").closest('.form-group').addClass('has-success');	  	
					}	

					if(productName == "") {
						$("#editproductName").after('<p class="text-danger">product Name field is required</p>');
						$('#editproductName').closest('.form-group').addClass('has-error');
					}	else {
						$("#editproductName").find('.text-danger').remove();
						$("#editproductName").closest('.form-group').addClass('has-success');	  	
					}	

					if(parameterStatus == "") {
						$("#editparameterStatus").after('<p class="text-danger">parameter Status field is required</p>');
						$('#editparameterStatus').closest('.form-group').addClass('has-error');
					}	else {
						$("#editparameterStatus").find('.text-danger').remove();
						$("#editparameterStatus").closest('.form-group').addClass('has-success');	  	
					}					

					if(parameterName && quantity && rate && companyName && productName && parameterStatus) {
						$("#editparameterBtn").button('loading');

						var form = $(this);
						var formData = new FormData(this);

						$.ajax({
							url : form.attr('action'),
							type: form.attr('method'),
							data: formData,
							dataType: 'json',
							cache: false,
							contentType: false,
							processData: false,
							success:function(response) {
								console.log(response);
								if(response.success == true) {
									$("#editparameterBtn").button('reset');																		

									$("html, body, div.modal, div.modal-content, div.modal-body").animate({scrollTop: '0'}, 100);
																			
									$('#edit-parameter-messages').html('<div class="alert alert-success">'+
				            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
				            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
				          '</div>');

				          $(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									});

									manageparameterTable.ajax.reload(null, true);

									$(".text-danger").remove();
									$(".form-group").removeClass('has-error').removeClass('has-success');

								} 
								
							} 
						}); 
					}						

					return false;
				}); 

						
				$("#updateparameterImageForm").unbind('submit').bind('submit', function() {					
					var parameterImage = $("#editparameterImage").val();					
					
					if(parameterImage == "") {
						$("#editparameterImage").closest('.center-block').after('<p class="text-danger">parameter Image field is required</p>');
						$('#editparameterImage').closest('.form-group').addClass('has-error');
					}	else {
						// remov error text field
						$("#editparameterImage").find('.text-danger').remove();
						$("#editparameterImage").closest('.form-group').addClass('has-success');	  	
					}	

					if(parameterImage) {
						$("#editparameterImageBtn").button('loading');

						var form = $(this);
						var formData = new FormData(this);

						$.ajax({
							url : form.attr('action'),
							type: form.attr('method'),
							data: formData,
							dataType: 'json',
							cache: false,
							contentType: false,
							processData: false,
							success:function(response) {
								
								if(response.success == true) {
									$("#editparameterImageBtn").button('reset');																		

									$("html, body, div.modal, div.modal-content, div.modal-body").animate({scrollTop: '0'}, 100);
																			
									$('#edit-parameterPhoto-messages').html('<div class="alert alert-success">'+
				            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
				            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
				          '</div>');

				          $(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									}); 

				       
									manageparameterTable.ajax.reload(null, true);

									$(".fileinput-remove-button").click();

									$.ajax({
										url: 'php_action/fetchparameterImageUrl.php?i='+parameterId,
										type: 'post',
										success:function(response) {
										$("#getparameterImage").attr('src', response);		
										}
									});																		

									$(".text-danger").remove();
									$(".form-group").removeClass('has-error').removeClass('has-success');

								} 
								
							} 
						}); 
					}	 					

					return false;
				}); 

			} 
		});

				
	} else {
		alert('error please refresh the page');
	}
} 


function removeparameter(parameterId = null) {
	if(parameterId) {
		$("#removeparameterBtn").unbind('click').bind('click', function() {
			$("#removeparameterBtn").button('loading');
			$.ajax({
				url: 'php_action/removeparameter.php',
				type: 'post',
				data: {parameterId: parameterId},
				dataType: 'json',
				success:function(response) {
					$("#removeparameterBtn").button('reset');
					if(response.success == true) {
						$("#removeparameterModal").modal('hide');

						manageparameterTable.ajax.reload(null, false);

						$(".remove-messages").html('<div class="alert alert-success">'+
		            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
		            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
		          '</div>');

	          $(".alert-success").delay(500).show(10, function() {
							$(this).delay(3000).hide(10, function() {
								$(this).remove();
							});
						});
					} else {

						$(".removeparameterMessages").html('<div class="alert alert-success">'+
		            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
		            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
		          '</div>');

	          $(".alert-success").delay(500).show(10, function() {
							$(this).delay(3000).hide(10, function() {
								$(this).remove();
							});
						}); 

					} 
				}
			}); 
			return false;
		}); 
	} 
} 

function clearForm(oForm) {
	
}