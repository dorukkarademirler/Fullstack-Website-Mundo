var manageproductTable;

$(document).ready(function() {
	$('#navproduct').addClass('active');	

	manageproductTable = $('#manageproductTable').DataTable({
		'ajax' : 'php_action/fetchproduct.php',
		'order': []
	}); 

	$('#addproductModalBtn').unbind('click').bind('click', function() {
		$("#submitproductForm")[0].reset();
		$(".text-danger").remove();
		$('.form-group').removeClass('has-error').removeClass('has-success');
		$("#submitproductForm").unbind('submit').bind('submit', function() {

			var productName = $("#productName").val();
			var productStatus = $("#productStatus").val();

			if(productName == "") {
				$("#productName").after('<p class="text-danger">product Name field is required</p>');
				$('#productName').closest('.form-group').addClass('has-error');
			} else {
				$("#productName").find('.text-danger').remove();
				$("#productName").closest('.form-group').addClass('has-success');	  	
			}

			if(productStatus == "") {
				$("#productStatus").after('<p class="text-danger">product Name field is required</p>');
				$('#productStatus').closest('.form-group').addClass('has-error');
			} else {
				$("#productStatus").find('.text-danger').remove();
				$("#productStatus").closest('.form-group').addClass('has-success');	  	
			}

			if(productName && productStatus) {
				var form = $(this);
				$("#createproductBtn").button('loading');

				$.ajax({
					url : form.attr('action'),
					type: form.attr('method'),
					data: form.serialize(),
					dataType: 'json',
					success:function(response) {
						$("#createproductBtn").button('reset');

						if(response.success == true) {
							manageproductTable.ajax.reload(null, false);						

							$("#submitproductForm")[0].reset();
							$(".text-danger").remove();
							$('.form-group').removeClass('has-error').removeClass('has-success');
	  	  			
	  	  			$('#add-product-messages').html('<div class="alert alert-success">'+
	            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
	            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
		          '</div>');

	  	  			$(".alert-success").delay(500).show(10, function() {
								$(this).delay(3000).hide(10, function() {
									$(this).remove();
								});
							}); 
						}  

					} 
				}); 
			} 

			return false;
		}); 
	}); 	

}); 

function editproduct(productId = null) {
	if(productId) {
		$('#editproductId').remove();
		$("#editproductForm")[0].reset();
		$(".text-danger").remove();
		$('.form-group').removeClass('has-error').removeClass('has-success');
		$("#edit-product-messages").html("");
		$('.modal-loading').removeClass('div-hide');
		$('.edit-product-result').addClass('div-hide');
		$(".editproductFooter").addClass('div-hide');		

		$.ajax({
			url: 'php_action/fetchSelectedproduct.php',
			type: 'post',
			data: {productId: productId},
			dataType: 'json',
			success:function(response) {

				$('.modal-loading').addClass('div-hide');
				$('.edit-product-result').removeClass('div-hide');
				$(".editproductFooter").removeClass('div-hide');	

				$("#editproductName").val(response.product_name);
				$("#editproductStatus").val(response.product_active);
				$(".editproductFooter").after('<input type="hidden" name="editproductId" id="editproductId" value="'+response.product_id+'" />');


				$("#editproductForm").unbind('submit').bind('submit', function() {
					var productName = $("#editproductName").val();
					var productStatus = $("#editproductStatus").val();

					if(productName == "") {
						$("#editproductName").after('<p class="text-danger">company Name field is required</p>');
						$('#editproductName').closest('.form-group').addClass('has-error');
					} else {
						$("#editproductName").find('.text-danger').remove();
						$("#editproductName").closest('.form-group').addClass('has-success');	  	
					}

					if(productStatus == "") {
						$("#editproductStatus").after('<p class="text-danger">company Name field is required</p>');
						$('#editproductStatus').closest('.form-group').addClass('has-error');
					} else {
						$("#editproductStatus").find('.text-danger').remove();
						$("#editproductStatus").closest('.form-group').addClass('has-success');	  	
					}

					if(productName && productStatus) {
						var form = $(this);
						$("#editproductBtn").button('loading');

						$.ajax({
							url : form.attr('action'),
							type: form.attr('method'),
							data: form.serialize(),
							dataType: 'json',
							success:function(response) {
								$("#editproductBtn").button('reset');

								if(response.success == true) {
									manageproductTable.ajax.reload(null, false);									  	  			
									
									$(".text-danger").remove();
									$('.form-group').removeClass('has-error').removeClass('has-success');
			  	  			
			  	  			$('#edit-product-messages').html('<div class="alert alert-success">'+
			            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
			            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
				          '</div>');

			  	  			$(".alert-success").delay(500).show(10, function() {
										$(this).delay(3000).hide(10, function() {
											$(this).remove();
										});
									}); 
								}  

							} 
						});
					} 

					return false;
				}); 

			} 
		}); 

	} else {
		alert('Oops!! Refresh the page');
	}
} 

function removeproduct(productId = null) {
		
	$.ajax({
		url: 'php_action/fetchSelectedproduct.php',
		type: 'post',
		data: {productId: productId},
		dataType: 'json',
		success:function(response) {			

			$("#removeproductBtn").unbind('click').bind('click', function() {
				$("#removeproductBtn").button('loading');

				$.ajax({
					url: 'php_action/removeproduct.php',
					type: 'post',
					data: {productId: productId},
					dataType: 'json',
					success:function(response) {
						if(response.success == true) {
							$("#removeproductBtn").button('reset');
							$("#removeproductModal").modal('hide');
							manageproductTable.ajax.reload(null, false);
							$('.remove-messages').html('<div class="alert alert-success">'+
	            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
	            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
		          '</div>');

	  	  			$(".alert-success").delay(500).show(10, function() {
								$(this).delay(3000).hide(10, function() {
									$(this).remove();
								});
							}); 
 						} else {
							$("#removeproductModal").modal('hide');

							$('.remove-messages').html('<div class="alert alert-success">'+
	            '<button type="button" class="close" data-dismiss="alert">&times;</button>'+
	            '<strong><i class="glyphicon glyphicon-ok-sign"></i></strong> '+ response.messages +
		          '</div>');

	  	  			$(".alert-success").delay(500).show(10, function() {
								$(this).delay(3000).hide(10, function() {
									$(this).remove();
								});
							}); 
 						} 
						
						
					} 
				});
			}); 

		}
	}); 
} 