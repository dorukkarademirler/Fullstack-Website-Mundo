<?php require_once 'includes/header.php'; ?>


<div class="row">
	<div class="col-md-12">

		
		<div class="panel panel-primary">
			<div class="panel-heading">
				<div class="page-heading">Manage product</div>
			</div>
			<div class="panel-body">

				<div class="remove-messages"></div>

				<div class="div-action pull pull-left" style="padding-bottom:20px;">
					<button class="btn btn-primary" data-toggle="modal" id="addproductModalBtn" data-target="#addproductModal">Add product </button>
				</div> 			
				
				<table class="table" id="manageproductTable">
					<thead>
						<tr>							
							<th>product Name</th>
							<th>product Status</th>
							<th style="width:15%;">Action</th>
						</tr>
					</thead>
				</table>
			

			</div> 
		</div> 	
	</div> 
</div>

<div class="modal fade" id="addproductModal" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">

    	<form class="form-horizontal" id="submitproductForm" action="php_action/createproduct.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title">Add product</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="add-product-messages"></div>

	        <div class="form-group">
	        	<label for="productName" class="col-sm-4 control-label">product Name: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-7">
				      <input type="text" class="form-control" id="productName" placeholder="product Name" name="productName" autocomplete="off">
				    </div>
	        </div>         	        
	        <div class="form-group">
	        	<label for="productStatus" class="col-sm-4 control-label">product Status: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-7">
				      <select class="form-control" id="productStatus" name="productStatus">
				      	<option value="">Select</option>
				      	<option value="1">Available</option>
				      	<option value="2">Not Available</option>
				      </select>
				    </div>
	        </div>          	        
	      </div> 
	      
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        
	        <button type="submit" class="btn btn-primary" id="createproductBtn" data-loading-text="Loading..." autocomplete="off">Save</button>
	      </div>       
     	</form>    
    </div>    
  </div> 
</div> 

<div class="modal fade" id="editproductModal" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="editproductForm" action="php_action/editproduct.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title">Edit product</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="edit-product-messages"></div>

	      	<div class="modal-loading div-hide" style="width:50px; margin:auto;padding-top:50px; padding-bottom:50px;">
						<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
						<span class="sr-only">Loading...</span>
					</div>

		      <div class="edit-product-result">
		      	<div class="form-group">
		        	<label for="editproductName" class="col-sm-4 control-label">Edit product Name: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-7">
					      <input type="text" class="form-control" id="editproductName" placeholder="product Name" name="editproductName" autocomplete="off">
					    </div>
		        </div>          	        
		        <div class="form-group">
		        	<label for="editproductStatus" class="col-sm-4 control-label">Edit product Status: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-7">
					      <select class="form-control" id="editproductStatus" name="editproductStatus">
					      	<option value="">Select</option>
					      	<option value="1">Available</option>
					      	<option value="2">Not Available</option>
					      </select>
					    </div>
		        </div>  
		      </div>         	        
		     

	      </div> 
	      
	      <div class="modal-footer editproductFooter">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        
	        <button type="submit" class="btn btn-success" id="editproductBtn" data-loading-text="Loading..." autocomplete="off">Save</button>
	      </div>
	     
     	</form>
	   
    </div>
  
  </div>
  
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="removeproductModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"> Remove product</h4>
      </div>
      <div class="modal-body">
        <p>Do you really want to remove product ?</p>
      </div>
      <div class="modal-footer removeproductFooter">
        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        <button type="button" class="btn btn-primary" id="removeproductBtn" data-loading-text="Loading...">Yes</button>
      </div>
    </div>
  </div>>
</div>



<script src="custom/js/product.js"></script>

<?php require_once 'includes/footer.php'; ?>