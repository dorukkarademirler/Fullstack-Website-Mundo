<?php require_once 'includes/header.php'; ?>


<div class="row">


	<div class="col-md-12">

				<div class="panel panel-primary">
			<div class="panel-heading">
				<div class="page-heading">Manage company</div>
			</div>
			<div class="panel-body">
				<div class="div-action pull pull-left" style="padding-bottom:20px;">
					<button class="btn btn-primary" data-toggle="modal" data-target="#addcompanyModel"> </i> Add company </button>
				</div> 				
				
				<table class="table" id="managecompanyTable">
					<thead>
						<tr>							
							<th>company Name</th>
							<th>company Status</th>
							<th style="width:15%;">Action</th>
						</tr>
					</thead>
				</table>
				

			</div>
		</div>	
	</div> 
</div> 

<div class="modal fade" id="addcompanyModel" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="submitcompanyForm" action="php_action/createcompany.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"> Add company</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="add-company-messages"></div>

	        <div class="form-group">
	        	<label for="companyName" class="col-sm-3 control-label">company Name: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="companyName" placeholder="company Name" name="companyName" autocomplete="off">
				    </div>
	        </div>         	        
	        <div class="form-group">
	        	<label for="companyStatus" class="col-sm-3 control-label">company Status: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <select class="form-control" id="companyStatus" name="companyStatus">
				      	<option value="">Select</option>
				      	<option value="1">Available</option>
				      	<option value="2">Not Available</option>
				      </select>
				    </div>
	        </div>         	        

	      </div> 
	      
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        
	        <button type="submit" class="btn btn-primary" id="createcompanyBtn" data-loading-text="Loading..." autocomplete="off">Save</button>
	      </div>
     	</form>
	    
    </div>
    
  </div>
 
</div>



<div class="modal fade" id="editcompanyModel" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	
    	<form class="form-horizontal" id="editcompanyForm" action="php_action/editcompany.php" method="POST">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"> Edit company</h4>
	      </div>
	      <div class="modal-body">

	      	<div id="edit-company-messages"></div>

	      	<div class="modal-loading div-hide" style="width:50px; margin:auto;padding-top:50px; padding-bottom:50px;">
												<span class="sr-only">Loading...</span>
					</div>

		      <div class="edit-company-result">
		      	<div class="form-group">
		        	<label for="editcompanyName" class="col-sm-3 control-label">Edit company Name: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-8">
					      <input type="text" class="form-control" id="editcompanyName" placeholder="company Name" name="editcompanyName" autocomplete="off">
					    </div>
		        </div>          	        
		        <div class="form-group">
		        	<label for="editcompanyStatus" class="col-sm-3 control-label">Edit company Status: </label>
		        	<label class="col-sm-1 control-label">: </label>
					    <div class="col-sm-8">
					      <select class="form-control" id="editcompanyStatus" name="editcompanyStatus">
					      	<option value="">Select</option>
					      	<option value="1">Available</option>
					      	<option value="2">Not Available</option>
					      </select>
					    </div>
		        </div> 	
		      </div>         	        
		     

	      </div> 
	      
	      <div class="modal-footer editcompanyFooter">
	        <button type="button" class="btn btn-default" data-dismiss="modal"> Close</button>
	        
	        <button type="submit" class="btn btn-primary" id="editcompanyBtn" data-loading-text="Loading..." autocomplete="off">Save</button>
	      </div>
	   
     	</form>
	   
    </div>

  </div>

</div>

<div class="modal fade" tabindex="-1" role="dialog" id="removeMemberModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"> Remove company</h4>
      </div>
      <div class="modal-body">
        <p>Do you really want to remove the company ?</p>
      </div>
      <div class="modal-footer removecompanyFooter">
        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        <button type="button" class="btn btn-primary" id="removecompanyBtn" data-loading-text="Loading...">Yes</button>
      </div>
    </div>
  </div>
</div>


<script src="custom/js/company.js"></script>

<?php require_once 'includes/footer.php'; ?>