<?php require_once 'php_action/core.php'; ?>

<!DOCTYPE html>
<html>
<head>

	<title>MUNDO | RAMP</title>

<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="custom/css/custom.css">
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">
	<script src="assests/jquery/jquery.min.js"></script>
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

	<script src="assests/bootstrap/js/bootstrap.min.js"></script>

</head>
<body>

<br/><br/>
	
    
		<div class="container">
       <center><h2 style="font-family:verdana;"><b>Stock</b> <mark>Management System</mark></h2><br/></center>
         
    
    <nav class="nav class="navbar navbar-light" style="background-color: #E9E9C0;">
    <a class="navbar-brand" href="dashboard.php"><b>Home</b></a>
    <a class="navbar-brand" href="company.php"><b>Company</b></a>
    <a class="navbar-brand" href="product.php"><b>Product</b></a>
    <a class="navbar-brand" href="parameter.php"><b>Parameter</b></a>
    <a class="navbar-brand" href="orders.php?o=add"><b>Add Orders</b></a>
    <a class="navbar-brand" href="orders.php?o=manord"><b>Manage Orders</b></a>
    <a class="navbar-brand" href="progress.php"><b>Progress</b></a>
    <a class="navbar-brand" href="setting.php"><b>Manage Account</b></a>
    <a class="navbar-brand" href="logout.php"><b>Logout</b></a>    
  </nav>   

      
    
  </div>
	

	<div class="container"><br/>