<?php require_once 'includes/header.php'; ?>

<div class="row">
	<div class="col-md-12">
		<div class="panel panel-primary">
			<div class="panel-heading">
				Progress
			</div>
		
			<div class="panel-body">
				
				<form class="form-horizontal" action="php_action/getOrderprogress.php" method="post" id="getOrderprogressForm">
				  <div class="form-group">
				    <label for="startDate" class="col-sm-2 control-label">From</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="startDate" name="startDate" placeholder="Start Date" />
				    </div>
				  </div>
				  <div class="form-group">
				    <label for="endDate" class="col-sm-2 control-label">To</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="endDate" name="endDate" placeholder="End Date" />
				    </div>
				  </div>
				  <div class="form-group">
				    <div class="col-sm-offset-2 col-sm-10">
				      <button type="submit" class="btn btn-primary" id="generateprogressBtn"> Generate progress</button>
				    </div>
				  </div>
				</form>

			</div>
			
		</div>
	</div>
	
</div>


<script src="custom/js/progress.js"></script>

<?php require_once 'includes/footer.php'; ?>