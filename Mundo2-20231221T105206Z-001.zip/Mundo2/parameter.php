<?php require_once 'php_action/db_connect.php' ?>
<?php require_once 'includes/header.php'; ?>

<div class="row">
	<div class="col-md-12">

				<div class="panel panel-primary">
			<div class="panel-heading">
				<div class="page-heading"> Manage Parameter</div>
			</div> 
			<div class="panel-body">

				<div class="remove-messages"></div>

				<div class="div-action pull pull-left" style="padding-bottom:20px;">
					<button class="btn btn-primary" data-toggle="modal" id="addparameterModalBtn" data-target="#addparameterModal">Add Parameter </button>
				</div> 			
				
				<table class="table" id="manageparameterTable">
					<thead>
						<tr>
							<th style="width:10%;">Photo</th>							
							<th>Parameter Name</th>
							<th>Rate</th>							
							<th>Quantity</th>
							<th>company</th>
							<th>product</th>
							<th>Status</th>
							<th style="width:15%;">Action</th>
						</tr>
					</thead>
				</table>
				

			</div> 
		</div> 	
	</div> 
</div> 


<div class="modal fade" id="addparameterModal" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">

    	<form class="form-horizontal" id="submitparameterForm" action="php_action/createparameter.php" method="POST" enctype="multipart/form-data">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title">Add Parameter</h4>
	      </div>

	      <div class="modal-body" style="max-height:450px; overflow:auto;">

	      	<div id="add-parameter-messages"></div>

	      	<div class="form-group">
	        	<label for="parameterImage" class="col-sm-3 control-label">Parameter Image: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
							<div id="kv-avatar-errors-1" class="center-block" style="display:none;"></div>							
					    <div class="kv-avatar center-block">					        
					        <input type="file" class="form-control" id="parameterImage" placeholder="parameter Name" name="parameterImage" class="file-loading" style="width:auto;"/>
					    </div>
				      
				    </div>
	        </div>      	           	       

	        <div class="form-group">
	        	<label for="parameterName" class="col-sm-3 control-label">Parameter Name: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="parameterName" placeholder="parameter Name" name="parameterName" autocomplete="off">
				    </div>
	        </div>     

	        <div class="form-group">
	        	<label for="quantity" class="col-sm-3 control-label">Quantity: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="quantity" placeholder="Quantity" name="quantity" autocomplete="off">
				    </div>
	        </div>         	 

	        <div class="form-group">
	        	<label for="rate" class="col-sm-3 control-label">Rate: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <input type="text" class="form-control" id="rate" placeholder="Rate" name="rate" autocomplete="off">
				    </div>
	        </div>      	        

	        <div class="form-group">
	        	<label for="companyName" class="col-sm-3 control-label">company Name: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <select class="form-control" id="companyName" name="companyName">
				      	<option value="">Select</option>
				      	<?php 
				      	$sql = "SELECT company_id, company_name, company_active, company_status FROM company WHERE company_status = 1 AND company_active = 1";
								$result = $connect->query($sql);

								while($row = $result->fetch_array()) {
									echo "<option value='".$row[0]."'>".$row[1]."</option>";
								} 
								
				      	?>
				      </select>
				    </div>
	        </div> 

	        <div class="form-group">
	        	<label for="productName" class="col-sm-3 control-label">product Name: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <select type="text" class="form-control" id="productName" placeholder="parameter Name" name="productName" >
				      	<option value="">Select</option>
				      	<?php 
				      	$sql = "SELECT product_id, product_name, product_active, product_status FROM product WHERE product_status = 1 AND product_active = 1";
								$result = $connect->query($sql);

								while($row = $result->fetch_array()) {
									echo "<option value='".$row[0]."'>".$row[1]."</option>";
								} // while
								
				      	?>
				      </select>
				    </div>
	        </div> 				        	         	       

	        <div class="form-group">
	        	<label for="parameterStatus" class="col-sm-3 control-label">Status: </label>
	        	<label class="col-sm-1 control-label">: </label>
				    <div class="col-sm-8">
				      <select class="form-control" id="parameterStatus" name="parameterStatus">
				      	<option value="">Select</option>
				      	<option value="1">Available</option>
				      	<option value="2">Not Available</option>
				      </select>
				    </div>
	        </div>          	        
	      </div>
	      
	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">  Close</button>
	        
	        <button type="submit" class="btn btn-primary" id="createparameterBtn" data-loading-text="Loading..." autocomplete="off">  Save</button>
	      </div>       
     	</form>      
    </div> 
  </div> 
</div> 

<div class="modal fade" id="editparameterModal" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
    	    	
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title"> Edit Parameter</h4>
	      </div>
	      <div class="modal-body" style="max-height:450px; overflow:auto;">

	      	<div class="div-loading">
	      		<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
						<span class="sr-only">Loading...</span>
	      	</div>

	      	<div class="div-result">

				  <ul class="nav nav-tabs" role="tablist">
				    <li role="presentation" class="active"><a href="#photo" aria-controls="home" role="tab" data-toggle="tab">Photo</a></li>
				    <li role="presentation"><a href="#parameterInfo" aria-controls="profile" role="tab" data-toggle="tab">Parameter Info</a></li>    
				  </ul>

				  <div class="tab-content">

				  	
				    <div role="tabpanel" class="tab-pane active" id="photo">
				    	<form action="php_action/editparameterImage.php" method="POST" id="updateparameterImageForm" class="form-horizontal" enctype="multipart/form-data">

				    	<br />
				    	<div id="edit-parameterPhoto-messages"></div>

				    	<div class="form-group">
			        	<label for="editparameterImage" class="col-sm-3 control-label">Parameter Image: </label>
			        	<label class="col-sm-1 control-label">: </label>
						    <div class="col-sm-8">							    				   
						      <img src="" id="getparameterImage" class="thumbnail" style="width:250px; height:250px;" />
						    </div>
			        </div>      	           	       
				    	
			      	<div class="form-group">
			        	<label for="editparameterImage" class="col-sm-3 control-label">Select Photo: </label>
			        	<label class="col-sm-1 control-label">: </label>
						    <div class="col-sm-8">
									<div id="kv-avatar-errors-1" class="center-block" style="display:none;"></div>							
							    <div class="kv-avatar center-block">					        
							        <input type="file" class="form-control" id="editparameterImage" placeholder="parameter Name" name="editparameterImage" class="file-loading" style="width:auto;"/>
							    </div>
						      
						    </div>
			        </div>      	           	       

			        <div class="modal-footer editparameterPhotoFooter">
				        <button type="button" class="btn btn-default" data-dismiss="modal">  Close</button>
				        
				      
				      </div>
				     
				      </form>
				  
				    </div>
				  
				    <div role="tabpanel" class="tab-pane" id="parameterInfo">
				    	<form class="form-horizontal" id="editparameterForm" action="php_action/editparameter.php" method="POST">				    
				    	<br />

				    	<div id="edit-parameter-messages"></div>

				    	<div class="form-group">
			        	<label for="editparameterName" class="col-sm-3 control-label">Parameter Name: </label>
			        	<label class="col-sm-1 control-label">: </label>
						    <div class="col-sm-8">
						      <input type="text" class="form-control" id="editparameterName" placeholder="parameter Name" name="editparameterName" autocomplete="off">
						    </div>
			        </div>    

			        <div class="form-group">
			        	<label for="editQuantity" class="col-sm-3 control-label">Quantity: </label>
			        	<label class="col-sm-1 control-label">: </label>
						    <div class="col-sm-8">
						      <input type="text" class="form-control" id="editQuantity" placeholder="Quantity" name="editQuantity" autocomplete="off">
						    </div>
			        </div> 	        	 

			        <div class="form-group">
			        	<label for="editRate" class="col-sm-3 control-label">Rate: </label>
			        	<label class="col-sm-1 control-label">: </label>
						    <div class="col-sm-8">
						      <input type="text" class="form-control" id="editRate" placeholder="Rate" name="editRate" autocomplete="off">
						    </div>
			        </div>     	        

			        <div class="form-group">
			        	<label for="editcompanyName" class="col-sm-3 control-label">company Name: </label>
			        	<label class="col-sm-1 control-label">: </label>
						    <div class="col-sm-8">
						      <select class="form-control" id="editcompanyName" name="editcompanyName">
						      	<option value="">Select</option>
						      	<?php 
						      	$sql = "SELECT company_id, company_name, company_active, company_status FROM company WHERE company_status = 1 AND company_active = 1";
										$result = $connect->query($sql);

										while($row = $result->fetch_array()) {
											echo "<option value='".$row[0]."'>".$row[1]."</option>";
										} // while
										
						      	?>
						      </select>
						    </div>
			        </div> 

			        <div class="form-group">
			        	<label for="editproductName" class="col-sm-3 control-label">product Name: </label>
			        	<label class="col-sm-1 control-label">: </label>
						    <div class="col-sm-8">
						      <select type="text" class="form-control" id="editproductName" name="editproductName" >
						      	<option value="">Select</option>
						      	<?php 
						      	$sql = "SELECT product_id, product_name, product_active, product_status FROM product WHERE product_status = 1 AND product_active = 1";
										$result = $connect->query($sql);

										while($row = $result->fetch_array()) {
											echo "<option value='".$row[0]."'>".$row[1]."</option>";
										} // while
										
						      	?>
						      </select>
						    </div>
			        </div> 				        	         	       

			        <div class="form-group">
			        	<label for="editparameterStatus" class="col-sm-3 control-label">Status: </label>
			        	<label class="col-sm-1 control-label">: </label>
						    <div class="col-sm-8">
						      <select class="form-control" id="editparameterStatus" name="editparameterStatus">
						      	<option value="">Select</option>
						      	<option value="1">Available</option>
						      	<option value="2">Not Available</option>
						      </select>
						    </div>
			        </div> 	         	        

			        <div class="modal-footer editparameterFooter">
				        <button type="button" class="btn btn-default" data-dismiss="modal">  Close</button>
				        
				        <button type="submit" class="btn btn-primary" id="editparameterBtn" data-loading-text="Loading...">Save</button>
				      </div> 			     
			        </form> 			     	
				    </div>    
				    
				  </div>

				</div>
	      	
	      </div> 
	      	      
     	
    </div>
  
  </div>
  
</div>


<div class="modal fade" tabindex="-1" role="dialog" id="removeparameterModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title"> Remove Parameter</h4>
      </div>
      <div class="modal-body">

      	<div class="removeparameterMessages"></div>

        <p>Do you really want to remove the parameter?</p>
      </div>
      <div class="modal-footer removeparameterFooter">
        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        <button type="button" class="btn btn-primary" id="removeparameterBtn" data-loading-text="Loading...">  Yes</button>
      </div>
    </div>
  </div>
</div>



<script src="custom/js/parameter.js"></script>

<?php require_once 'includes/footer.php'; ?>