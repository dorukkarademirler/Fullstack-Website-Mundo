<?php require_once 'includes/header.php'; ?>


<?php 

$sql = "SELECT * FROM parameter WHERE status = 1";
$query = $connect->query($sql);
$countparameter = $query->num_rows;
$sql2 = "SELECT * FROM parameter WHERE status = 2";
$query2 = $connect->query($sql2);
$countparameter2 = $query->num_rows;

$companySql = "SELECT * FROM company WHERE company_status = 1";
$companyQuery = $connect->query($companySql);
$countcompany = $companyQuery->num_rows;
$companySql2 = "SELECT * FROM company WHERE company_status = 2";
$companyQuery2 = $connect->query($companySql2);
$countcompany2 = $companyQuery2->num_rows;


$productSql = "SELECT * FROM product WHERE product_status = 1";
$productQuery = $connect->query($productSql);
$countproduct = $productQuery->num_rows;
$productSql2 = "SELECT * FROM product WHERE product_status = 2";
$productQuery2 = $connect->query($productSql2);
$countproduct2 = $productQuery2->num_rows;

$orderSql = "SELECT * FROM orders WHERE order_status = 1";
$orderQuery = $connect->query($orderSql);
$countOrder = $orderQuery->num_rows;
$orderSql2 = "SELECT * FROM orders WHERE order_status = 2";
$orderQuery2 = $connect->query($orderSql2);
$countOrder2 = $orderQuery2->num_rows;

$totalRevenue = 0;
while ($orderResult = $orderQuery->fetch_assoc()) {
	$totalRevenue += $orderResult['paid'];
}

$lowStockSql = "SELECT * FROM parameter WHERE quantity <= 10 AND status = 1";
$lowStockQuery = $connect->query($lowStockSql);
$countLowStock = $lowStockQuery->num_rows;

$connect->close();

?>


<div class="row">

<div class="col-md-3">
<div class="panel panel-primary" >
<div class="panel-heading" >Company</div>
<div class="panel-body" >
<a href="company.php" style="text-decoration:none;color:green;">Active 			
<span class="badge pull pull-right"><?php echo $countcompany; ?></span>	
</a><hr>
<a href="company.php" style="text-decoration:none;color:red;">InActive 				
<span class="badge pull pull-right"><?php echo $countcompany2; ?></span>	
</a>
</div>
</div>

<div class="panel panel-primary" >
<div class="panel-heading" >Product</div>
<div class="panel-body" >
<a href="product.php" style="text-decoration:none;color:green;">Active					
<span class="badge pull pull-right"><?php echo $countproduct; ?></span>	
</a><hr>
<a href="product.php" style="text-decoration:none;color:red;">In Active					
<span class="badge pull pull-right"><?php echo $countproduct2; ?></span>	
</a>
</div>
</div>
</div>

	<div class="col-md-6"><hr>
    
        <center><a href = "dashboard.php"><img src = "logo.jpg"></a></center><hr><br/>
		 <div class="panel panel-default" >
			
			<div class="panel-body" >
				<a href="parameter.php" style="text-decoration:none;color:red;">
					Product Stock Alert (Less than 10 units)
					<span class="badge pull pull-right"><?php echo $countLowStock; ?></span>	
				</a>
			</div>
            
</div>



	</div>

<div class="col-md-3">
<div class="panel panel-primary" >
<div class="panel-heading" >Orders</div>
<div class="panel-body" >
<a href="orders.php?o=manord" style="text-decoration:none;color:black;">
New Orders
<span class="badge pull pull-right"><?php echo $countOrder; ?></span>	
</a><hr>
<a href="orders.php?o=manord" style="text-decoration:none;color:black;">
Settled Orders
<span class="badge pull pull-right"><?php echo $countOrder2; ?></span>	
</a>
</div>	
            
</div>

<div class="panel panel-primary" >
<div class="panel-heading" >Parameters</div>
<div class="panel-body" >
<a href="parameter.php" style="text-decoration:none;color:green;">Active 			
<span class="badge pull pull-right"><?php echo $countparameter; ?></span>	
</a><hr>
<a href="parameter.php" style="text-decoration:none;color:red;">InActive 				
<span class="badge pull pull-right"><?php echo $countparameter2; ?></span>	
</a>
</div>
</div>



</div>





</div> 

<?php require_once 'includes/footer.php'; ?>